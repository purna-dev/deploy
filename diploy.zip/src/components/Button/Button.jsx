import React from 'react'
import style from './Button.module.css'
function Button() {
  return (
    <div className={style.cusbutton}>
    Get started for free
    </div>
  )
}

export default Button