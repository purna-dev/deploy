import React from 'react'
import style from './Products.module.css'
function Products() {
  return (
    <div>Products</div>
  )
}

export default Products